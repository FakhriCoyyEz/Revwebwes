console.clear();
window.addEventListener('click', onClickParticles);
function onClickParticles(e) {
  let container;
  if (document.querySelector('.rs-firework-container') === null) {
    container = document.createElement('div');
    container.classList.add('rs-firework-container');
    document.body.appendChild(container);
  } else {
    container = document.querySelector('.rs-firework-container');
  }
  for (var i = 0; i < 30; i++) {
    var particle = document.createElement('span');
    container.appendChild(particle);
    var size = 5;
    var x = e.clientX - size / 2;
    var y = e.clientY - size / 2;
    var tl = gsap.timeline({});
    tl.set(particle, {
      x: x,
      y: y,
      width: size,
      height: size,
      background: function (index) {
        var hue = index / 60 * 90 + 250;
        return `hsl(${hue}, 50%, 50%`;
      }
    });
    tl.to(particle, Math.random() * 1 + 0.5, {
      x: x + (Math.random() - 0.5) * 100,
      y: y + (Math.random() - 0.5) * 100,
      opacity: 0,
      onComplete: function () {
        container.removeChild(this._targets[0]);
      }
    });
  }
}
function removeAllChildNodes(parent) {
  while (parent.firstChild) {
    parent.removeChild(parent.firstChild);
  }
}