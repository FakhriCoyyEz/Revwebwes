$(document).ready(function() {
  var counter = 0;
  var c = 0;
  var i = setInterval(function() {
      $(".loading-page .counter h1").html(c + "%");
      $(".loading-page .counter hr").css("width", c + "%");

      // Increment the counter and percentage value
      counter++;
      c++;

      // Check if the loading reaches 100%
      if (counter === 101) {
          clearInterval(i);  // Stop the interval when loading is done
          // Redirect to the index.html page after the loading is done
          window.location.href = "index.html";
      }
  }, 50);  // The loading speed (50ms interval per 1% increment)
});
