window.addEventListener('scroll', function() {
    const overlay = document.getElementById('header-overlay');
    let scrollPosition = window.scrollY;
  
    if (scrollPosition > 100) { // Change this value based on when you want the effect to start
      overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)'; // Increase opacity as you scroll
    } else {
      overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)'; // Original opacity
    }
  });
  
  /* Testo */

 